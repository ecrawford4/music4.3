<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method Not Allowed');
}

if (!isset($_POST['notedata']) || $_POST['notedata'] === '') {
    http_response_code(400);
    exit('Missing notedata');
}

$midiClassPath = __DIR__ . '/midi.class.php';
if (!is_file($midiClassPath)) {
    http_response_code(500);
    exit('MIDI library missing');
}

require_once $midiClassPath;

set_error_handler(function ($severity, $message, $file, $line) {
    throw new ErrorException($message, 0, $severity, $file, $line);
});

try {
    $txt = (string) $_POST['notedata'];
    $txt = str_replace("\r", '', $txt);
    $txt = trim($txt) . "\n";

    $midi = new Midi();
    $midi->importTxt($txt);

    $binaryMidi = $midi->getMid();
    if ($binaryMidi === '' || $binaryMidi === false) {
        throw new Exception('MIDI generation returned empty data');
    }

    $destFilename = 'output3A.mid';

    header('Content-Type: application/octet-stream');
    header('Expires: ' . gmdate('D, d M Y H:i:s') . ' GMT');
    header('Content-Disposition: attachment; filename="' . $destFilename . '"');
    header('Pragma: no-cache');
    header('Content-Length: ' . strlen($binaryMidi));

    echo $binaryMidi;
} catch (Exception $e) {
    http_response_code(500);
    exit('Failed to create MIDI');
} finally {
    restore_error_handler();
}
?>
