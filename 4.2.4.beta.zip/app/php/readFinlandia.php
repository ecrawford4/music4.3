<?php
header('Content-Type: application/json; charset=utf-8');

$sourcePath = __DIR__ . '/Finlandia';
if (!is_readable($sourcePath)) {
    http_response_code(500);
    echo json_encode(array('error' => 'Source file is not readable'));
    exit;
}

$result = file($sourcePath, FILE_IGNORE_NEW_LINES);
if ($result === false) {
    http_response_code(500);
    echo json_encode(array('error' => 'Failed to read source file'));
    exit;
}

echo json_encode($result);